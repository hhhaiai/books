OrangePi5

- SSD启动跑5.10的Ubuntu22.04：提升运行速度
    - TF卡启动：下载桌面版镜像 刷入TF卡 
    - 接入键鼠、WIFI模块、HDMI显示器、启动进入桌面
    - SSD启动：刷入U-Boot to the SPI：更新bootloader
    https://github.com/Joshua-Riek/ubuntu-rockchip/wiki/Orange-Pi-5#install-the-bootloader-to-the-spi-nor-flash
    - 初始化完成，进入SSD里面的系统    
- 配置docker云原生手机
    - 远程桌面：remmina + Ubuntu Sharing
    - 更换源为国内版本：https://blog.csdn.net/winter2121/article/details/119892416
    - 为裸板安装docker：https://t.zsxq.com/13AxdHrWQ
    - 安装驱动和配置、最后跑云手机：https://t.zsxq.com/13wWVUDHU
- frida/objection/r0cap
    - 先装pipx、然后pipx install frida-tools objection
- Linux内核编译与替换开启eBPF
    - 从源码编译内核：从项目的actions里寻找依赖等流程
    - 运行编译命令：./build.sh -b orangepi-5 --kernel-only
    - 编译deb包成功
    - 当前内核：Linux roysue-desktop 5.10.160-rockchip #15 SMP Sun Oct 8 15:01:49 UTC 2023 aarch64 aarch64 aarch64 GNU/Linux
    - sudo dpkg -i linux-image-5.10.160-rockchip_5.10.160-16_arm64.deb
    - flash-kernel: installing version 5.10.160-rockchip
    - 重启后 HDMI驱动坏了 ssh可以连接
    - 开启eBPF的配置：https://mp.weixin.qq.com/s/lrNwArEMsIKsigjhSFprQg
    - 被dpkg-buildpackage自动生成的.config配置覆盖掉了
    ```
    #
    # configuration written to .config
    #
    ```
    - fault injection 错误注入的思想 定位.config重新生成的配置命令的那一行 删掉：rockchip_linux_defconfig
    https://github.com/Joshua-Riek/linux-rockchip/blob/ac973b5afd84196742e185e673ea0f8dfae9b825/debian/rules#L24C10-L24C36
    - 编译完成之后安装之后就有全功能的eBPF了
    - $ uname -a
Linux roysue-desktop 5.10.160-rockchip #17 SMP Wed Oct 25 18:07:58 CST 2023 aarch64 aarch64 aarch64 GNU/Linux
    - 下载链接：https://t.zsxq.com/13nJwac6N  下载5.10.160-15 的那个是ok的

- eCap/estrace/stackplz
- ？Magisk/Lsposed
- ？抓包NG


手机的优点：做研究、逆向、分析、完整的环境
裸板的优点：无电池无WIFI用有线、(超)大规模部署、向外提供方案、价格便宜实惠、学习全功能Linux/eBPF




sudo ./build.sh -b orangepi-5 --kernel-only
dpkg-buildpackage: info: source package linux-rockchip-5.10.160
dpkg-buildpackage: info: source version 5.10.160-16
dpkg-buildpackage: info: source distribution jammy
dpkg-buildpackage: info: source changed by Joshua Riek <jjriek@verizon.net>
 dpkg-source --before-build .
dpkg-buildpackage: info: host architecture arm64
dpkg-source: info: using options from linux-rockchip/debian/source/options: --compression-level=3 --compression=xz --tar-ignore=.git --diff-ignore --tar-ignore
 debian/rules build
/usr/bin/make rockchip_linux_defconfig \
  CROSS_COMPILE= \
  ARCH=arm64 \
  -j 8
make[1]: Entering directory '/home/roysue/Desktop/ubuntu-rockchip/build/linux-rockchip'
scripts/Makefile.build:44: scripts/kconfig/Makefile: No such file or directory
make[2]: *** No rule to make target 'scripts/kconfig/Makefile'.  Stop.
make[1]: *** [Makefile:630: rockchip_linux_defconfig] Error 2
make[1]: Leaving directory '/home/roysue/Desktop/ubuntu-rockchip/build/linux-rockchip'
make: *** [debian/rules:24: config] Error 2
dpkg-buildpackage: error: debian/rules build subprocess returned exit status 2
Error: in ./scripts/build-kernel.sh on line 19
Error: in ./build.sh on line 135



make[1]: Entering directory '/home/roysue/Desktop/ubuntu-rockchip/build/linux-rockchip'
  SYNC    include/config/auto.conf.cmd
scripts/Makefile.build:44: scripts/kconfig/Makefile: No such file or directory
make[3]: *** No rule to make target 'scripts/kconfig/Makefile'.  Stop.
make[2]: *** [Makefile:630: syncconfig] Error 2
make[1]: *** [Makefile:750: include/config/auto.conf.cmd] Error 2
make[1]: *** [include/config/auto.conf.cmd] Deleting file 'include/generated/autoconf.h'
make[1]: Leaving directory '/home/roysue/Desktop/ubuntu-rockchip/build/linux-rockchip'
make: *** [debian/rules:24: config] Error 2
dpkg-buildpackage: error: debian/rules build subprocess returned exit status 2
Error: in ./scripts/build-kernel.sh on line 19
Error: in ./build.sh on line 135



./build.sh -b orangepi-5 --kernel-only
dpkg-buildpackage: info: source package linux-rockchip-5.10.160
dpkg-buildpackage: info: source version 5.10.160-15
dpkg-buildpackage: info: source distribution jammy
dpkg-buildpackage: info: source changed by Joshua Riek <jjriek@verizon.net>
 dpkg-source --before-build .
dpkg-buildpackage: info: host architecture arm64
dpkg-source: info: using options from linux-rockchip/debian/source/options: --compression-level=3 --compression=xz --tar-ignore=.git --diff-ignore --tar-ignore
 debian/rules build
/usr/bin/make rockchip_linux_defconfig \
  CROSS_COMPILE= \
  ARCH=arm64 \
  -j 8
make[1]: Entering directory '/root/ubuntu-rockchip/build/linux-rockchip'
scripts/Makefile.build:44: scripts/kconfig/Makefile: No such file or directory
make[2]: *** No rule to make target 'scripts/kconfig/Makefile'.  Stop.
make[1]: *** [Makefile:630: rockchip_linux_defconfig] Error 2
make[1]: Leaving directory '/root/ubuntu-rockchip/build/linux-rockchip'
make: *** [debian/rules:24: config] Error 2
dpkg-buildpackage: error: debian/rules build subprocess returned exit status 2
Error: in ./scripts/build-kernel.sh on line 19
Error: in ./build.sh on line 135




error: Cannot resolve BTF IDs for CONFIG_DEBUG_INFO_BTF, please install libelf-dev, libelf-devel or elfutils-libelf-devel
make[1]: *** [Makefile:1378: prepare-resolve_btfids] Error 1
make[1]: *** Waiting for unfinished jobs....
make[1]: Leaving directory '/root/ubuntu-rockchip/build/linux-rockchip'
make: *** [debian/rules:31: build-arch] Error 2
dpkg-buildpackage: error: debian/rules build subprocess returned exit status 2
Error: in ./scripts/build-kernel.sh on line 19
Error: in ./build.sh on line 135


apt install libelf-dev


BTF: .tmp_vmlinux.btf: pahole (pahole) is not available
Failed to generate BTF for vmlinux
Try to disable CONFIG_DEBUG_INFO_BTF
make[1]: *** [Makefile:1307: vmlinux] Error 1
make[1]: Leaving directory '/root/ubuntu-rockchip/build/linux-rockchip'
make: *** [debian/rules:31: build-arch] Error 2
dpkg-buildpackage: error: debian/rules build subprocess returned exit status 2
Error: in ./scripts/build-kernel.sh on line 19
Error: in ./build.sh on line 135

apt install dwarves



zcat /proc/config.gz | grep PROBE
CONFIG_GENERIC_IRQ_PROBE=y
CONFIG_ARCH_SUPPORTS_UPROBES=y
CONFIG_KPROBES=y
CONFIG_UPROBES=y
CONFIG_KRETPROBES=y
CONFIG_HAVE_KPROBES=y
CONFIG_HAVE_KRETPROBES=y
# CONFIG_TEST_ASYNC_DRIVER_PROBE is not set
CONFIG_GENERIC_CPU_AUTOPROBE=y
# CONFIG_MTD_JEDECPROBE is not set
CONFIG_TIMER_PROBE=y
CONFIG_KPROBE_EVENTS=y
CONFIG_KPROBE_EVENTS_ON_NOTRACE=y
CONFIG_UPROBE_EVENTS=y
CONFIG_PROBE_EVENTS=y
CONFIG_BPF_KPROBE_OVERRIDE=y
CONFIG_KPROBE_EVENT_GEN_TEST=y
# CONFIG_KPROBES_SANITY_TEST is not set



作业二：Orangepi5从SSD启动到云手机到跑frida
作业三：OrangePi5编译内核启动eBPF支持云手机里跑eCap成功