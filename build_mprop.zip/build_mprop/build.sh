/home/ubuntu/Android/Sdk/ndk/21.1.6352462/ndk-build
#source  /home/ubuntu/aosp/push_client.sh
# https://github.com/moritz-wundke/Boost-for-Android build-android.sh
