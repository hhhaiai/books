package com.yuandaima;

import android.util.Log;

public class HelloService extends IHelloService.Stub {

    private ICallback mCallback; 
    private static final String TAG = "HelloService";
    private int cnt1 = 0;
    private int cnt2 = 0;

    public void sayhello() throws android.os.RemoteException {
        cnt1++;
        Log.i(TAG, "sayhello : cnt = "+cnt1);
        if (mCallback != null) {
            mCallback.onMessage("message from Server");
        }
    }
    
    public int sayhello_to(java.lang.String name) throws android.os.RemoteException {
        cnt2++;
        Log.i(TAG, "sayhello_to "+name+" : cnt = "+cnt2);
        return cnt2;
    }

    //添加注册回调函数
    public void registerCallback(int pid, ICallback callback) {
        Log.d(TAG, "register callback receive");
        mCallback = callback;
    }

}