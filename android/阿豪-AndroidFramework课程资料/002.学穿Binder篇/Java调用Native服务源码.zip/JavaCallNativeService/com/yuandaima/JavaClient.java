package com.yuandaima;

import android.util.Log;
import android.os.ServiceManager;
import android.os.RemoteException;
import android.os.IBinder;
import android.os.Parcel;

public class JavaClient {

    public static final String TAG = "JavaClient";

    public static void main(String[] args) {
        //获取Native Binder Service的代理
        IBinder binder = ServiceManager.getService("IHello");
        //String DESCRIPTOR = "com.yuandaima.IHello";
        
        //
        IHello svr = IHello.Stub.asInterface(binder);

        try {
	        svr.hello();
	        Log.i(TAG, "call hello");
        } catch (Exception e) {

        }
           
        try {
	        int cnt = svr.sum(3, 4);
	        Log.i(TAG, "call sum(3, 4)");
        } catch (Exception e) {
    
        }
    
    }
}
