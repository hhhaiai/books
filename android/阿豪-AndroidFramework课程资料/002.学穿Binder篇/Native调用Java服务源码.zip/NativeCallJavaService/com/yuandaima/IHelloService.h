#ifndef AIDL_GENERATED_COM_YUANDAIMA_I_HELLO_SERVICE_H_
#define AIDL_GENERATED_COM_YUANDAIMA_I_HELLO_SERVICE_H_

#include <binder/IBinder.h>
#include <binder/IInterface.h>
#include <binder/Status.h>
#include <cstdint>
#include <utils/String16.h>
#include <utils/StrongPointer.h>

namespace com {

namespace yuandaima {

class IHelloService : public ::android::IInterface {
public:
  DECLARE_META_INTERFACE(HelloService)
  virtual ::android::binder::Status sayhello() = 0;
  virtual ::android::binder::Status sayhello_to(const ::android::String16& name, int32_t* _aidl_return) = 0;
};  // class IHelloService

class IHelloServiceDefault : public IHelloService {
public:
  ::android::IBinder* onAsBinder() override;
  ::android::binder::Status sayhello() override;
  ::android::binder::Status sayhello_to(const ::android::String16& name, int32_t* _aidl_return) override;

};

}  // namespace yuandaima

}  // namespace com

#endif  // AIDL_GENERATED_COM_YUANDAIMA_I_HELLO_SERVICE_H_
