#define LOG_TAG "aidl_cpp"
#include <log/log.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <android/log.h>
#include <errno.h>
#include <binder/IServiceManager.h>
#include <binder/IBinder.h>
#include <binder/Parcel.h>
#include <binder/ProcessState.h>
#include <binder/IPCThreadState.h>
#include <private/binder/binder_module.h>
#include <string.h>
#include <cutils/properties.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <linux/fs.h>
#include <stdarg.h>
#include <stdlib.h>
#include "com/yuandaima/IHelloService.h"

using namespace android;
 
 
int  main(void)
{   

    // sp<IServiceManager> sm = defaultServiceManager();
	// sp<IBinder> ibinder =  sm->getService(String16("hello")); 

	// Parcel data,reply;

	// if(ibinder != NULL)
	// {
    // 	static String16 descriptor = String16("com.yuandaima.IHelloService");
    //     data.writeInterfaceToken(descriptor);
	// 	data.writeString16(String16("client from Native"));
	// 	ibinder->transact(IBinder::FIRST_CALL_TRANSACTION + 0, data, &reply, 0);
	// 	int result = reply.readInt32();
	// 	ALOGI("transact result : %d\n", result);
	//     return 0;
    // }

	sp<ProcessState> proc(ProcessState::self());
    sp<IServiceManager> sm = defaultServiceManager();

    sp<IBinder> binder = sm->getService(String16("hello"));

    sp<com::yuandaima::IHelloService> service =
		    interface_cast<com::yuandaima::IHelloService>(binder);

    if (binder == 0)
	{
		ALOGI("can't get hello service\n");
		return -1;
	}

    service->sayhello();
	int32_t result;
    service->sayhello_to(String16("nihao"), &result);
	ALOGI("client call sayhello_to, result = %d", result);

}
